﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Tailwind.Traders.Rewards.Web.data
{
    public enum EnrollmentStatusEnum
    {
        Uninitialized,
        Started,
        Accepted,
        Rejected,
        Uncompleted
    }
}