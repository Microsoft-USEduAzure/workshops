﻿using Newtonsoft.Json;
using System;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tailwind.Traders.Rewards.Web.data;

namespace Tailwind.Traders.Rewards.Web
{
    public partial class OrderDetail : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string yolo = Request.QueryString["yolo"];
            if (yolo == "hi")

            {
                throw new Exception();
            }

            var cid = -1;
            if (Page.IsPostBack)
            {
                cid = int.Parse(CustomerId.Value);
            }
            using (var ctx = new ContextDB())
            {
                var orderNo = Request.QueryString["OrderNo"];
                var orders = ctx.Orders.Where(x => x.Code == orderNo).ToList();

                orderList.DataSource = orders;
                orderList.DataBind();

                if (cid == -1)
                {
                    var defaultCustomer = ctx.Customers.FirstOrDefault();
                    MapCustomer(defaultCustomer);
                }
                else
                {
                    var customer = ctx.Customers.Single(c => c.CustomerId == cid);
                    MapCustomer(customer);
                }
            }
        }

        protected void EnrollChckedChanged(object sender, EventArgs e)
        {
            var cid = int.Parse(CustomerId.Value);
            using (var ctx = new ContextDB())
            {
                var customer = ctx.Customers
                    .Where(c => c.CustomerId == cid)
                    .SingleOrDefault();

                if (customer.Enrrolled == EnrollmentStatusEnum.Uninitialized)
                {
                    customer.Enrrolled = EnrollmentStatusEnum.Started;
                    ctx.SaveChanges();
                    BypassLogicAppIfNeeded(customer);
                    MapCustomer(customer);
                }
            }
        }

        private void BypassLogicAppIfNeeded(Customer customer)
        {
            var bypassSettings = ConfigurationManager.AppSettings["ByPassLogicApp"];
            if (string.IsNullOrEmpty(bypassSettings) || !bool.Parse(bypassSettings))
            {
                return;
            }

            var channel = ConfigurationManager.AppSettings["ChannelType"] ?? "Email";

            var uri = ConfigurationManager.AppSettings["AfHttpHandlerUri"];

            var client = new HttpClient();
            var obj = new
            {
                enrolled = customer.Enrrolled,
                firstName = customer.FirstName,
                id = customer.CustomerId,
                lastName = customer.LastName,
                mobileNumber = customer.MobileNumber,
                Email = customer.Email,
                Channel = channel
            };
            var json = JsonConvert.SerializeObject(obj);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var result = client.PostAsync(uri, content).Result;
        }

        private void MapCustomer(Customer customer)
        {
            CustomerId.Value = customer.CustomerId.ToString();
            AccNo.InnerText = customer.AccountCode;
            Address1.InnerText = customer.FirstAddress;
            City.InnerText = customer.City;
            Country.InnerText = customer.Country;
            ZipCode.InnerText = customer.ZipCode;
            Website.InnerText = customer.Website;
            Active.InnerText = customer.Active ? "yes" : "no";
            Name.InnerText = customer.FirstName;
            LastName.InnerText = customer.LastName;
            Email.InnerText = customer.Email;
            PhoneNumber.InnerText = customer.PhoneNumber;
            FaxNumber.InnerText = customer.FaxNumber;
            MobileNumber.InnerText = customer.MobileNumber;
        }
    }
}